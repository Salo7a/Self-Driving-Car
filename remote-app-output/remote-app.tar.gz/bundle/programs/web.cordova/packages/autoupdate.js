//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Retry = Package.retry.Retry;
var DDP = Package['ddp-client'].DDP;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package.modules.meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-client'].Symbol;
var Map = Package['ecmascript-runtime-client'].Map;
var Set = Package['ecmascript-runtime-client'].Set;

/* Package-scope variables */
var Autoupdate;

var require = meteorInstall({"node_modules":{"meteor":{"autoupdate":{"autoupdate_cordova.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/autoupdate/autoupdate_cordova.js                                                       //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  Autoupdate: function () {
    return Autoupdate;
  }
});
var ClientVersions;
module.link("./client_versions.js", {
  ClientVersions: function (v) {
    ClientVersions = v;
  }
}, 0);
var autoupdateVersionsCordova = __meteor_runtime_config__.autoupdate.versions["web.cordova"] || {
  version: "unknown"
};
var Autoupdate = {};
// Stores acceptable client versions.
var clientVersions = new ClientVersions();
Meteor.connection.registerStore("meteor_autoupdate_clientVersions", clientVersions.createStore());

Autoupdate.newClientAvailable = function () {
  return clientVersions.newClientAvailable("web.cordova", ["version"], autoupdateVersionsCordova);
};

var retry = new Retry({
  // Unlike the stream reconnect use of Retry, which we want to be instant
  // in normal operation, this is a wacky failure. We don't want to retry
  // right away, we can start slowly.
  //
  // A better way than timeconstants here might be to use the knowledge
  // of when we reconnect to help trigger these retries. Typically, the
  // server fixing code will result in a restart and reconnect, but
  // potentially the subscription could have a transient error.
  minCount: 0,
  // don't do any immediate retries
  baseTimeout: 30 * 1000 // start with 30s

});
var failures = 0;

Autoupdate._retrySubscription = function () {
  var _meteor_runtime_conf = __meteor_runtime_config__,
      appId = _meteor_runtime_conf.appId;
  Meteor.subscribe("meteor_autoupdate_clientVersions", appId, {
    onError: function (error) {
      console.log("autoupdate subscription failed:", error);
      failures++;
      retry.retryLater(failures, function () {
        // Just retry making the subscription, don't reload the whole
        // page. While reloading would catch more cases (for example,
        // the server went back a version and is now doing old-style hot
        // code push), it would also be more prone to reload loops,
        // which look really bad to the user. Just retrying the
        // subscription over DDP means it is at least possible to fix by
        // updating the server.
        Autoupdate._retrySubscription();
      });
    },
    onReady: function () {
      if (Package.reload) {
        var checkNewVersionDocument = function (doc) {
          if (doc.version !== autoupdateVersionsCordova.version) {
            newVersionAvailable();
          }
        };

        clientVersions.watch(checkNewVersionDocument, {
          filter: "web.cordova"
        });
      }
    }
  });
};

Meteor.startup(function () {
  WebAppLocalServer.onNewVersionReady(function () {
    if (Package.reload) {
      Package.reload.Reload._reload();
    }
  });

  Autoupdate._retrySubscription();
});

function newVersionAvailable() {
  WebAppLocalServer.checkForUpdates();
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"client_versions.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/autoupdate/client_versions.js                                                          //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
var _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default: function (v) {
    _objectSpread = v;
  }
}, 0);
module.export({
  ClientVersions: function () {
    return ClientVersions;
  }
});
var Tracker;
module.link("meteor/tracker", {
  Tracker: function (v) {
    Tracker = v;
  }
}, 0);

var ClientVersions = /*#__PURE__*/function () {
  function ClientVersions() {
    this._versions = new Map();
    this._watchCallbacks = new Set();
  } // Creates a Livedata store for use with `Meteor.connection.registerStore`.
  // After the store is registered, document updates reported by Livedata are
  // merged with the documents in this `ClientVersions` instance.


  var _proto = ClientVersions.prototype;

  _proto.createStore = function () {
    function createStore() {
      var _this = this;

      return {
        update: function (_ref) {
          var id = _ref.id,
              msg = _ref.msg,
              fields = _ref.fields;

          if (msg === "added" || msg === "changed") {
            _this.set(id, fields);
          }
        }
      };
    }

    return createStore;
  }();

  _proto.hasVersions = function () {
    function hasVersions() {
      return this._versions.size > 0;
    }

    return hasVersions;
  }();

  _proto.get = function () {
    function get(id) {
      return this._versions.get(id);
    }

    return get;
  }() // Adds or updates a version document and invokes registered callbacks for the
  // added/updated document. If a document with the given ID already exists, its
  // fields are merged with `fields`.
  ;

  _proto.set = function () {
    function set(id, fields) {
      var version = this._versions.get(id);

      var isNew = false;

      if (version) {
        Object.assign(version, fields);
      } else {
        version = _objectSpread({
          _id: id
        }, fields);
        isNew = true;

        this._versions.set(id, version);
      }

      this._watchCallbacks.forEach(function (_ref2) {
        var fn = _ref2.fn,
            filter = _ref2.filter;

        if (!filter || filter === version._id) {
          fn(version, isNew);
        }
      });
    }

    return set;
  }() // Registers a callback that will be invoked when a version document is added
  // or changed. Calling the function returned by `watch` removes the callback.
  // If `skipInitial` is true, the callback isn't be invoked for existing
  // documents. If `filter` is set, the callback is only invoked for documents
  // with ID `filter`.
  ;

  _proto.watch = function () {
    function watch(fn) {
      var _this2 = this;

      var _ref3 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          skipInitial = _ref3.skipInitial,
          filter = _ref3.filter;

      if (!skipInitial) {
        var resolved = Promise.resolve();

        this._versions.forEach(function (version) {
          if (!filter || filter === version._id) {
            resolved.then(function () {
              return fn(version, true);
            });
          }
        });
      }

      var callback = {
        fn: fn,
        filter: filter
      };

      this._watchCallbacks.add(callback);

      return function () {
        return _this2._watchCallbacks.delete(callback);
      };
    }

    return watch;
  }() // A reactive data source for `Autoupdate.newClientAvailable`.
  ;

  _proto.newClientAvailable = function () {
    function newClientAvailable(id, fields, currentVersion) {
      function isNewVersion(version) {
        return version._id === id && fields.some(function (field) {
          return version[field] !== currentVersion[field];
        });
      }

      var dependency = new Tracker.Dependency();
      var version = this.get(id);
      dependency.depend();
      var stop = this.watch(function (version) {
        if (isNewVersion(version)) {
          dependency.changed();
          stop();
        }
      }, {
        skipInitial: true
      });
      return !!version && isNewVersion(version);
    }

    return newClientAvailable;
  }();

  return ClientVersions;
}();
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/autoupdate/autoupdate_cordova.js");

/* Exports */
Package._define("autoupdate", exports, {
  Autoupdate: Autoupdate
});

})();
