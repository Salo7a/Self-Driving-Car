//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MeteorCamera = Package['mdg:camera'].MeteorCamera;

/* Package-scope variables */
var MeteorCameraUI;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/okland_camera-ui/packages/okland_camera-ui.js                              //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/okland:camera-ui/camera-ui.js                                        //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
MeteorCameraUI = {};                                                             // 1
                                                                                 // 2
                                                                                 // 3
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/okland:camera-ui/camera-ui-client.js                                 //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * Helper function for uploading base 64 image to server.                        // 2
 * @summary Take JPEG image dataURI and return blob of the given content type    // 3
 * @returns {Blob}                                                               // 4
 */                                                                              // 5
MeteorCameraUI.dataURIToBlob = function (dataURI) {                              // 6
  // Check that input exists                                                     // 7
  if (!dataURI) {                                                                // 8
    return;                                                                      // 9
  }                                                                              // 10
  //                                                                             // 11
  var splitedDataURI = dataURI.split(',');                                       // 12
  // Split the image base64 from dataURI                                         // 13
  if (!splitedDataURI || splitedDataURI.length < 2) {                            // 14
    return;                                                                      // 15
  }                                                                              // 16
  var base64 = splitedDataURI[1];                                                // 17
  return MeteorCameraUI.b64toBlob(base64, 'image/jpeg');                         // 18
};                                                                               // 19
                                                                                 // 20
                                                                                 // 21
/**                                                                              // 22
 * Helper function for uploading base 64 image to server.                        // 23
 * @summary Take base 64 data and return blob of the given content type          // 24
 * @param b64Data                                                                // 25
 * @param contentType                                                            // 26
 * @param sliceSize                                                              // 27
 * @returns {Blob}                                                               // 28
 */                                                                              // 29
MeteorCameraUI.b64toBlob = function (b64Data, contentType, sliceSize) {          // 30
  contentType = contentType || '';                                               // 31
  sliceSize = sliceSize || 512;                                                  // 32
                                                                                 // 33
  var byteCharacters = atob(b64Data);                                            // 34
  var byteArrays = [];                                                           // 35
                                                                                 // 36
  for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {    // 37
    var slice = byteCharacters.slice(offset, offset + sliceSize);                // 38
                                                                                 // 39
    var byteNumbers = new Array(slice.length);                                   // 40
    for (var i = 0; i < slice.length; i++) {                                     // 41
      byteNumbers[i] = slice.charCodeAt(i);                                      // 42
    }                                                                            // 43
                                                                                 // 44
    var byteArray = new Uint8Array(byteNumbers);                                 // 45
                                                                                 // 46
    byteArrays.push(byteArray);                                                  // 47
  }                                                                              // 48
                                                                                 // 49
  var blob;                                                                      // 50
  try {                                                                          // 51
    blob = new Blob(byteArrays, {type: contentType});                            // 52
  }                                                                              // 53
  catch (e) {                                                                    // 54
    // TypeError old chrome and FF                                               // 55
    window.BlobBuilder = window.BlobBuilder ||                                   // 56
      window.WebKitBlobBuilder ||                                                // 57
      window.MozBlobBuilder ||                                                   // 58
      window.MSBlobBuilder;                                                      // 59
    if (e.name == 'TypeError' && window.BlobBuilder) {                           // 60
      var bb = new BlobBuilder();                                                // 61
      bb.append(byteArrays);                                                     // 62
      blob = bb.getBlob(contentType);                                            // 63
    }                                                                            // 64
    else if (e.name == "InvalidStateError") {                                    // 65
      // InvalidStateError (tested on FF13 WinXP)                                // 66
      blob = new Blob(byteArrays, {type: contentType});                          // 67
    }                                                                            // 68
    else {                                                                       // 69
      // We're screwed, blob constructor unsupported entirely                    // 70
      console.error('b64toBlob: blob constructor unsupported entirely');         // 71
    }                                                                            // 72
  }                                                                              // 73
  return blob;                                                                   // 74
};                                                                               // 75
                                                                                 // 76
/**                                                                              // 77
 * @summary Just use regular MeteorCamera.getPicture method                      // 78
 * @param {Object}   options  Options - Optional                                 // 79
 * @param {Number} options.height The minimum height of the image                // 80
 * @param {Number} options.width The minimum width of the image                  // 81
 * @param {Number} options.quality [description]                                 // 82
 * @type {Function}                                                              // 83
 */                                                                              // 84
MeteorCameraUI.getPictureNoUI = MeteorCamera.getPicture;                         // 85
                                                                                 // 86
                                                                                 // 87
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/okland:camera-ui/camera-ui-browser.js                                //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * @summary Get a picture from the device's default camera.                      // 2
 *          Same as MeteorCamera.getPicture just allow to give                   // 3
 *          special options using options.browserOptions.                        // 4
 * @param  {Object}   options  Options                                           // 5
 * @param {Number} options.height The minimum height of the image                // 6
 * @param {Number} options.width The minimum width of the image                  // 7
 * @param {Number} options.quality [description]                                 // 8
 * @param {Object} options.browserOptions [special options only for browser]     // 9
 * @param  {Function} callback A callback that is called with two arguments:     // 10
 * 1. error, an object that contains error.message and possibly other properties // 11
 * depending on platform                                                         // 12
 * 2. data, a Data URI string with the image encoded in JPEG format, ready to    // 13
 * use as the `src` attribute on an `<img />` tag.                               // 14
 */                                                                              // 15
MeteorCameraUI.getPicture = function (options, callback) {                       // 16
  // If browser options exists use them                                          // 17
  if (options && options.browserOptions) {                                       // 18
    options = _.extend({}, options.browserOptions, options);                     // 19
  }                                                                              // 20
  MeteorCamera.getPicture(options, callback);                                    // 21
};                                                                               // 22
                                                                                 // 23
///////////////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("okland:camera-ui", {
  MeteorCameraUI: MeteorCameraUI
});

})();
