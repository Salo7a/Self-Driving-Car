(function () {



/* Exports */
Package._define("templating");

})();
